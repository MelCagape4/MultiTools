from unittest import TestCase
from externalizer import gitlabclient

class propertyParserTestCase(TestCase):
    
    # WARNING: REMOVE THE VALUES FROM THESE VARIABLES BEFORE COMMITTING TO THE BRANCH
    url = 'https://gitlab.metrobank.com.ph/'
    token = 'glpat-sMxLQaBGFWUuxDqh3Qfp'
    searchPrefix = 'externalized-mbs-'
    testRepo01 = 'externalization/ci-cd/mbo/externalized-mbs-casa-service'
    testRepo02 = 'externalization/ci-cd/mbo/externalized-mbs-biller-service'
    templatePath = 'template/application.properties'
    valuePath = 'conf/sit1.prop.value'
    
    def test_getAllProjects(self):
        projects = gitlabclient.getAllProjectsByKeyword(self.url, self.token, self.searchPrefix)
        
        assert len(projects) > 0
        
        template, value = gitlabclient.getProjectTemplateValueContents(self.url, self.token, self.testRepo01, self.templatePath, self.valuePath)
        
        assert template != ''
        assert value != ''
        

    def test_getAllRepositoryFiles(self):
        envNamelist = list()
        envNamelist.extend(("DEV", "SIT", "SIT1", "SIT2", "UAT", "UAT-SKYNET"))
        template, values = gitlabclient.getAllRepositoryFiles(self.url, self.token, envNamelist, self.testRepo01)
        print(template)
        #for v in values:
        #    print('')
        #    print(v['envName'])
        #    for c in v['values']:
        #        print(c)
        