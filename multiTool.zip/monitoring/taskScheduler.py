from logsearch import sshclient
from externalizer import dbclient
import json

moduleHCSSO = 'tasks.healthcheck.sso'
moduleHCMFA = 'tasks.healthcheck.mfa'

componentCommand = 'command'
componentTargetServer = 'serverip'
componentUsername = 'username'
componentPassword = 'password'
componentResultType = 'resulttype'
componentCriteria = 'criteria'
componentCriteriaValue = 'criteriavalue'

valueResultTypeJson = 'json'


def checkModule(module):
    print('checkModule() == ' + module)
    return checkCriteria(getResultOutput(module), module)


def getResultOutput(module):
    print('getResultOutput() === ' + module)
    ip = dbclient.getConfigurationValue(module + '.' + componentTargetServer)
    username = dbclient.getConfigurationValue(module + '.' + componentUsername)
    password = dbclient.getConfigurationValue(module + '.' + componentPassword)
    command = dbclient.getConfigurationValue(module + '.' + componentCommand)
    return sshclient.executeSSHCommand(ip, username, password, command)


def checkCriteria(responseOutput, module):
    print('checkCriteria() === ' + responseOutput + ' === ' + module)
    outputType = dbclient.getConfigurationValue(module + '.' + componentResultType)
    
    if outputType == 'json':
        criteriaList = getComponentValueList(module, componentCriteria)
        criteriaValueList = getComponentValueList(module, componentCriteriaValue)
        valueListCount = len(criteriaValueList)
        index = 0
        for criteria in criteriaList:
            criteriaValue = None
            if index < valueListCount:
                criteriaValue = criteriaValueList[index]
                
            index += 1
            
            if criteriaValue: # if there is a criteria value, check values (DB vs JSON)
                if criteriaValue != str(getJsonValue(responseOutput, criteria)):
                    return False
            else: # else, check if criteria can be found in output
                try:
                    criteriaValue = getJsonValue(responseOutput, criteria)
                except ValueError:
                    return False
        
    else:  # else, the output is a string
        print('')
    return True
    
    
def getJsonValue(jsonString, jsonKey):
    print('getJsonValue() === ' + jsonString + ' === ' + jsonKey)
    jsonKeyList = jsonKey.split('.')
    outputJSON = json.loads(jsonString)
    keyJSON = outputJSON
    for key in jsonKeyList:
        keyJSON = keyJSON[key]
            
    return keyJSON


def getComponentValueList(module, component):
    print('getComponentValueList() === ' + module + ' === ' + component)
    componentValueList = list()
    
    loopCount = 0
    loop = True
    while loop:
        try:
            componentValueList.append(dbclient.getConfigurationValue(module + '.' + component + str(loopCount)))
            loopCount += 1
        except ValueError:
            loop = False

    return componentValueList    
