SECRET_KEY = "fake-key"
INSTALLED_APPS = [
    "tests"
]