from datetime import datetime
from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse
from externalizer import dbclient, propertyParser, gitlabclient
from logsearch import sshclient
import json

paramEnvironment = 'environment'
paramSelectedServers = 'servers'
paramSelectedService = 'service'
paramSearchKeyword = 'keyword'
paramPropertyDataSource = 'propertyDataSource'

propertyDataSource = ('Services', 'Repositories')

def editor(request):
    if request.user.username: 
        print('editor()')
        # sshclient.executeSUDOCommand()
        # Renders the externalizer page.
        
        
        assert isinstance(request, HttpRequest)
        return render(
            request,
            'monitoring.html',
            {
                'year':datetime.now().year,
            }
        )
    else:
       # REDIRECT TO LOGIN 
       return redirect('../toolsadmin/login/?next=/monitoring/')
   
