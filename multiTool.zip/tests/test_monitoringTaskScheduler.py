from monitoring import taskScheduler
import json
from unittest import TestCase

class TaskSchedulerTestCase(TestCase):
    
    def test_getJsonValue(self):
        jsonPayload = '''
        {
            "key1":"value1",
            "key2":{
                "key3":"value3",
                "key4":{
                    "key5":"value5"
                }
            }
        }
        '''
        assert taskScheduler.getJsonValue(jsonPayload, "key2.key4.key5") == 'value5'
        assert taskScheduler.getJsonValue(jsonPayload, "key1") == 'value1'
        assert taskScheduler.getJsonValue(jsonPayload, "key2.key3") == 'value3'
        assert type(taskScheduler.getJsonValue(jsonPayload, "key2.key4")) == dict
        

    def test_getComponentValueList(self):
        componentValueList = taskScheduler.getComponentValueList('test.module', 'component')
        assert componentValueList[0] == 'testmodulecomponent0'
        assert componentValueList[1] == 'testmodulecomponent1'
        

    def test_checkCriteria_JSON(self):
        output = '''
        {
            "key1":"value1",
            "key2":{
                "key3":"value3",
                "key4":{
                    "key5":"value5"
                }
            }
        }
        '''
        assert taskScheduler.checkCriteria(output, 'test.module') == True
        
        output = '''
        {
            "key1":"value4",
            "key2":{
                "key3":"value3",
                "key4":{
                    "key5":"value5"
                }
            }
        }
        '''
        assert taskScheduler.checkCriteria(output, 'test.module') == False
        

    def test_getResultOutput_mfa(self):
        output = taskScheduler.getResultOutput(taskScheduler.moduleHCMFA)
        outputJSON = json.loads(output)
        assert outputJSON['statusCode'] == 200
        

    def test_getResultOutput_sso(self):
        output = taskScheduler.getResultOutput(taskScheduler.moduleHCSSO)
        outputJSON = json.loads(output)
        assert outputJSON['token_type'] == 'bearer'
        

    def test_checkModule(self):
        assert taskScheduler.checkModule(taskScheduler.moduleHCSSO) == True
        assert taskScheduler.checkModule(taskScheduler.moduleHCMFA) == True